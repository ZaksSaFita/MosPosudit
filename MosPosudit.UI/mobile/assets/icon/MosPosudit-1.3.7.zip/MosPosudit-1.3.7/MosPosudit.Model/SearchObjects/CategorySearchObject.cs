namespace MosPosudit.Model.SearchObjects
{
    public class CategorySearchObject : BaseSearchObject
    {
        public string? Name { get; set; }
    }
}

