namespace MosPosudit.Model.SearchObjects
{
    public class UserFavoriteSearchObject : BaseSearchObject
    {
        public int? UserId { get; set; }
        public int? ToolId { get; set; }
    }
}

