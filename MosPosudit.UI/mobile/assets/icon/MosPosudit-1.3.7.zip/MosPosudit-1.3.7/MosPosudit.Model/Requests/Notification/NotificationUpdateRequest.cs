namespace MosPosudit.Model.Requests.Notification
{
    public class NotificationUpdateRequest
    {
        public bool? IsRead { get; set; }
    }
}

