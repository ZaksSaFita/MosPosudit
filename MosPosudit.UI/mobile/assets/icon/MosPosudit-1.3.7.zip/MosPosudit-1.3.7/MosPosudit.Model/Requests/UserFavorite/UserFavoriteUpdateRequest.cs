namespace MosPosudit.Model.Requests.UserFavorite
{
    public class UserFavoriteUpdateRequest
    {
        // UserFavorite doesn't support update operations
        // This class exists only for BaseCrudService compatibility
    }
}

