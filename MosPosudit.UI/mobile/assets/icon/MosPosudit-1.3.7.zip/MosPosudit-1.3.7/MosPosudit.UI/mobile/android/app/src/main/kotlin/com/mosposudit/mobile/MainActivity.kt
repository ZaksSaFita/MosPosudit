package com.mosposudit.mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

